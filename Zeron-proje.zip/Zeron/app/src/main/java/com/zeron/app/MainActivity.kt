package com.zeron.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.*
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.webkit.*
import java.text.Normalizer
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    lateinit var web: WebView
    var tts: TextToSpeech? = null
    var sr: SpeechRecognizer? = null
    var voices = listOf<Voice>()
    var vIdx = 0
    var torch = false
    val tr = Locale("tr", "TR")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Zeron")
        web.webChromeClient = WebChromeClient()
        setContentView(web)
        tts = TextToSpeech(this, this)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(s: Int) {
        tts?.language = tr
        val all = tts?.voices?.filter { it.locale.language == "tr" } ?: emptyList()
        // erkek sesi öne al: Google TTS'te "tmc/tmg" kodlu sesler erkek, diğerleri kadın olabilir
        voices = all.sortedBy { v -> if (Regex("tmc|tmg|male|erkek", RegexOption.IGNORE_CASE).containsMatchIn(v.name)) 0 else 1 }
        if (voices.isNotEmpty()) tts?.voice = voices[0]
        tts?.setPitch(0.72f); tts?.setSpeechRate(0.95f)
    }

    fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }
    fun norm(s: String) = Normalizer.normalize(s.lowercase(tr), Normalizer.Form.NFD).replace(Regex("\\p{Mn}"), "").replace("ı", "i")

    inner class Bridge {
        @JavascriptInterface fun speak(t: String) { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "z") }
        @JavascriptInterface fun nextVoice(): String {
            if (voices.isEmpty()) return "Cihazda Türkçe ses bulunamadı"
            vIdx = (vIdx + 1) % voices.size; tts?.voice = voices[vIdx]; return voices[vIdx].name
        }
        @JavascriptInterface fun listen() = runOnUiThread {
            sr?.destroy(); sr = SpeechRecognizer.createSpeechRecognizer(this@MainActivity)
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR").putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle) { val t = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""; js("onHeard(${org.json.JSONObject.quote(t)})") }
                override fun onError(e: Int) { js("onHeard('')") }
                override fun onReadyForSpeech(p: Bundle?) { js("setState('listening')") }
                override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
            })
            sr?.startListening(i)
        }
        @JavascriptInterface fun openApp(name: String): Boolean {
            val q = norm(name); val pm = packageManager
            val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val hit = pm.queryIntentActivities(li, 0).firstOrNull { norm(it.loadLabel(pm).toString()).contains(q) } ?: return false
            startActivity(pm.getLaunchIntentForPackage(hit.activityInfo.packageName)); return true
        }
        @JavascriptInterface fun settings(p: String) {
            val a = when (p) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS; "internet" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIRELESS_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS; "ucak" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                "ekran" -> Settings.ACTION_DISPLAY_SETTINGS; "ses" -> Settings.ACTION_SOUND_SETTINGS
                "pil" -> Intent.ACTION_POWER_USAGE_SUMMARY; "konum" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                "nfc" -> Settings.ACTION_NFC_SETTINGS; "hotspot" -> Settings.ACTION_WIRELESS_SETTINGS
                "depolama" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS; "uygulamalar" -> Settings.ACTION_APPLICATION_SETTINGS
                "rahatsiz" -> Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS; else -> Settings.ACTION_SETTINGS }
            startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun flashlight(on: Boolean) {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(cm.cameraIdList[0], on); torch = on
        }
        @JavascriptInterface fun volume(d: Int) {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (d > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }
        @JavascriptInterface fun mute() { (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI) }
        @JavascriptInterface fun alarm(h: Int, m: Int) { startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_SKIP_UI, true)) }
        @JavascriptInterface fun timer(sec: Int) { startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_SKIP_UI, true)) }
        @JavascriptInterface fun dial(n: String) { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n"))) }
        @JavascriptInterface fun battery(): Int { val b = getSystemService(BATTERY_SERVICE) as BatteryManager; return b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }
    }
}
