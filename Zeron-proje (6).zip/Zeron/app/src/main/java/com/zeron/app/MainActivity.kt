package com.zeron.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.*
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.speech.tts.UtteranceProgressListener
import android.content.pm.PackageManager
import android.view.WindowManager
import android.webkit.*
import java.text.Normalizer
import java.util.Locale
import org.json.*
import java.net.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    lateinit var web: WebView
    var tts: TextToSpeech? = null
    var sr: SpeechRecognizer? = null
    var voices = listOf<Voice>()
    var vIdx = 0
    var torch = false
    var wakeOn = false; var speaking = false; var cmdListening = false
    var wakeSr: SpeechRecognizer? = null
    val ui = Handler(Looper.getMainLooper())
    var muted = false
    fun setMute(on: Boolean) {
        if (muted == on) return
        muted = on
        try { (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0) } catch (e: Exception) {}
    }
    fun wakeKill(unmute: Boolean = true) { try { wakeSr?.destroy() } catch (e: Exception) {}; wakeSr = null; if (unmute) setMute(false) }
    fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var p = d[0]; d[0] = i
            for (j in 1..b.length) { val t = d[j]; d[j] = minOf(d[j] + 1, d[j - 1] + 1, p + (if (a[i - 1] == b[j - 1]) 0 else 1)); p = t }
        }
        return d[b.length]
    }
    fun findWake(n: String): Int {
        for (m in Regex("[a-z]+").findAll(n)) {
            val w = m.value
            if (w.endsWith("zeron") || (w.length in 4..7 && lev(w, "zeron") <= 1) || w == "zeyron" || w == "zeyrun") return m.range.last + 1
        }
        return -1
    }
    fun wakeLoop() {
        if (!wakeOn || speaking || cmdListening) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { ui.postDelayed({ wakeLoop() }, 3000); return }
        wakeKill(false)
        val s = SpeechRecognizer.createSpeechRecognizer(this); wakeSr = s
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR").putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        s.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle) {
                val t = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                val n = norm(t)
                if (t.isNotEmpty()) js("onWakeText(" + JSONObject.quote(t) + ")")
                val e = findWake(n)
                if (e >= 0 && wakeOn) {
                    wakeKill()
                    val rest = n.substring(e).trim(' ', ',', '.')
                    js("onWake(" + JSONObject.quote(rest) + ")")
                } else ui.postDelayed({ if (wakeSr === s) wakeLoop() }, 300)
            }
            override fun onError(e: Int) { js("onWakeText('hata $e')"); ui.postDelayed({ if (wakeSr === s) wakeLoop() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 400L) }
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
        })
        setMute(true)
        s.startListening(i)
    }
    override fun onDestroy() { setMute(false); super.onDestroy() }
    override fun onPause() { super.onPause(); wakeKill() }
    override fun onResume() { super.onResume(); if (wakeOn) wakeLoop() }
    val tr = Locale("tr", "TR")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Zeron")
        web.webChromeClient = WebChromeClient()
        setContentView(web)
        tts = TextToSpeech(this, this)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(s: Int) {
        tts?.language = tr
        val all = tts?.voices?.filter { it.locale.language == "tr" } ?: emptyList()
        // erkek sesi öne al: Google TTS'te "tmc/tmg" kodlu sesler erkek, diğerleri kadın olabilir
        voices = all.sortedBy { v -> if (Regex("tmc|tmg|male|erkek", RegexOption.IGNORE_CASE).containsMatchIn(v.name)) 0 else 1 }
        if (voices.isNotEmpty()) tts?.voice = voices[0]
        tts?.setPitch(0.72f); tts?.setSpeechRate(0.95f)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true; runOnUiThread { wakeKill() } }
            override fun onDone(id: String?) { speaking = false; js("onSpeakDone()") }
            override fun onError(id: String?) { speaking = false; js("onSpeakDone()") }
        })
    }

    fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }
    fun norm(s: String) = Normalizer.normalize(s.lowercase(tr), Normalizer.Form.NFD).replace(Regex("\\p{Mn}"), "").replace("ı", "i")

    inner class Bridge {

        val authRx = Regex("API key|API_KEY|\\b401\\b|\\b403\\b|PERMISSION", RegexOption.IGNORE_CASE)
        @JavascriptInterface fun ask(provider: String, key: String, model: String, system: String, hist: String, search: Boolean) {
            Thread {
                val out = try {
                    askAll(provider, key.filter { !it.isWhitespace() }, model.trim().removePrefix("models/").replace(" ", ""), system, JSONArray(hist), search)
                } catch (e: Exception) { "HATA: " + friendly(e.message ?: "bilinmiyor") }
                js("onAI(" + JSONObject.quote(out) + ")")
            }.start()
        }
        fun friendly(m: String): String {
            val t = when {
                authRx.containsMatchIn(m) -> "Anahtar geçersiz ya da yetkisiz, ayarlardan kontrol edin"
                m.contains("429") || m.contains("quota", true) || m.contains("RESOURCE_EXHAUSTED") -> "Ücretsiz kullanım sınırı doldu, biraz bekleyin"
                m.contains("resolve host") || m.contains("Unable to resolve") -> "İnternet bağlantısı yok ya da DNS sorunu var"
                m.contains("timeout", true) || m.contains("timed out", true) -> "Sunucu zamanında cevap vermedi"
                m.contains("404") || m.contains("model", true) -> "Model bulunamadı, ayarlarda model kutusunu boş bırakın"
                else -> "Beklenmeyen bir hata oldu"
            }
            return t + " | " + m.take(140)
        }
        var cachedModels: List<String>? = null
        fun geminiModels(key: String): List<String> {
            cachedModels?.let { return it }
            try {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.setRequestProperty("x-goog-api-key", key)
                if (c.responseCode >= 400) return emptyList()
                val arr = JSONObject(c.inputStream.bufferedReader().readText()).optJSONArray("models") ?: return emptyList()
                val rx = Regex("^models/(gemini-(\\d+(?:\\.\\d+)?)-flash)$")
                val found = ArrayList<Pair<Double, String>>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val mm = rx.find(o.optString("name")) ?: continue
                    val ok = o.optJSONArray("supportedGenerationMethods")?.toString()?.contains("generateContent") ?: true
                    if (ok) found.add(Pair(mm.groupValues[2].toDouble(), mm.groupValues[1]))
                }
                val list = found.sortedByDescending { it.first }.map { it.second }.take(3)
                if (list.isNotEmpty()) cachedModels = list
                return list
            } catch (e: Exception) { return emptyList() }
        }
        fun askAll(pr: String, key: String, model: String, sys: String, h: JSONArray, search: Boolean): String {
            val models = (if (pr == "gemini") listOf(model) + geminiModels(key) + listOf("gemini-flash-latest", "gemini-2.5-flash")
                          else listOf(model, "claude-haiku-5-5", "claude-sonnet-4-6")).filter { it.isNotEmpty() }.distinct()
            val end = System.currentTimeMillis() + 55000
            var last = "bilinmiyor"
            for (m in models) {
                for (tools in (if (search) listOf(true, false) else listOf(false))) {
                    var tries = 0
                    while (tries < 2 && System.currentTimeMillis() < end) {
                        tries++
                        try {
                            val r = call(pr, key, m, sys, h, tools)
                            if (r.isNotEmpty()) return r
                            last = "Boş cevap"; break
                        } catch (e: Exception) {
                            last = e.message ?: "bilinmiyor"
                            if (authRx.containsMatchIn(last)) return "HATA: " + friendly(last)
                            val net = last.contains("resolve host") || last.contains("timeout", true) || last.contains("timed out", true) || last.contains("failed to connect", true)
                            if (net && tries < 2) { Thread.sleep(1500); continue }
                            break
                        }
                    }
                }
            }
            return "HATA: " + friendly(last)
        }
        fun call(pr: String, key: String, model: String, sys: String, h: JSONArray, tools: Boolean): String {
            val body = JSONObject(); val u: String
            if (pr == "gemini") {
                u = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
                body.put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                val c = JSONArray()
                for (i in 0 until h.length()) {
                    val m = h.getJSONObject(i)
                    c.put(JSONObject().put("role", if (m.getString("role") == "user") "user" else "model").put("parts", JSONArray().put(JSONObject().put("text", m.getString("content")))))
                }
                body.put("contents", c)
                body.put("generationConfig", JSONObject().put("maxOutputTokens", 1024))
                if (tools) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            } else {
                u = "https://api.anthropic.com/v1/messages"
                body.put("model", model).put("max_tokens", 600).put("system", sys).put("messages", h)
                if (tools) body.put("tools", JSONArray().put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3)))
            }
            val c = URL(u).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 10000; c.readTimeout = if (tools) 25000 else 20000
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (pr == "gemini") c.setRequestProperty("x-goog-api-key", key)
            else { c.setRequestProperty("x-api-key", key); c.setRequestProperty("anthropic-version", "2023-06-01") }
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val txt = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
            if (code >= 400) {
                val msg = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt }
                throw Exception("$code " + msg.take(200))
            }
            val j = JSONObject(txt); val sb = StringBuilder()
            if (pr == "gemini") {
                val ps = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                if (ps == null) return "Bunu yanıtlayamıyorum efendim."
                for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
            } else {
                val ps = j.optJSONArray("content") ?: return ""
                for (i in 0 until ps.length()) if (ps.getJSONObject(i).optString("type") == "text") sb.append(ps.getJSONObject(i).optString("text"))
            }
            return sb.toString().trim()
        }
        @JavascriptInterface fun speak(t: String) {
            speaking = true; runOnUiThread { wakeKill() }
            val r = tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "z")
            if (r != TextToSpeech.SUCCESS) { speaking = false; js("onSpeakDone()") }
        }
        @JavascriptInterface fun wakeStart() = runOnUiThread { wakeOn = true; window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); wakeLoop() }
        @JavascriptInterface fun wakeStop() = runOnUiThread { wakeOn = false; window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); wakeKill() }
        @JavascriptInterface fun wakeResume() = runOnUiThread { if (wakeOn) wakeLoop() }
        @JavascriptInterface fun nextVoice(): String {
            if (voices.isEmpty()) return "Cihazda Türkçe ses bulunamadı"
            vIdx = (vIdx + 1) % voices.size; tts?.voice = voices[vIdx]; return voices[vIdx].name
        }
        @JavascriptInterface fun listen() = runOnUiThread {
            cmdListening = true; wakeKill()
            sr?.destroy(); sr = SpeechRecognizer.createSpeechRecognizer(this@MainActivity)
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR").putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle) { cmdListening = false; val t = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""; js("onHeard(${org.json.JSONObject.quote(t)})") }
                override fun onError(e: Int) { cmdListening = false; js("onHeard('')") }
                override fun onReadyForSpeech(p: Bundle?) { js("setState('listening')") }
                override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
            })
            sr?.startListening(i)
        }
        @JavascriptInterface fun openApp(name: String): Boolean {
            val q = norm(name); val pm = packageManager
            val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val hit = pm.queryIntentActivities(li, 0).firstOrNull { norm(it.loadLabel(pm).toString()).contains(q) } ?: return false
            startActivity(pm.getLaunchIntentForPackage(hit.activityInfo.packageName)); return true
        }
        @JavascriptInterface fun settings(p: String) {
            val a = when (p) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS; "internet" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIRELESS_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS; "ucak" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                "ekran" -> Settings.ACTION_DISPLAY_SETTINGS; "ses" -> Settings.ACTION_SOUND_SETTINGS
                "pil" -> Intent.ACTION_POWER_USAGE_SUMMARY; "konum" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                "nfc" -> Settings.ACTION_NFC_SETTINGS; "hotspot" -> Settings.ACTION_WIRELESS_SETTINGS
                "depolama" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS; "uygulamalar" -> Settings.ACTION_APPLICATION_SETTINGS
                "rahatsiz" -> Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS; else -> Settings.ACTION_SETTINGS }
            startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun flashlight(on: Boolean) {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(cm.cameraIdList[0], on); torch = on
        }
        @JavascriptInterface fun volume(d: Int) {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (d > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }
        @JavascriptInterface fun mute() { (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI) }
        @JavascriptInterface fun alarm(h: Int, m: Int) { startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_SKIP_UI, true)) }
        @JavascriptInterface fun timer(sec: Int) { startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_SKIP_UI, true)) }
        @JavascriptInterface fun dial(n: String) { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n"))) }
        @JavascriptInterface fun battery(): Int { val b = getSystemService(BATTERY_SERVICE) as BatteryManager; return b.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }
    }
}
